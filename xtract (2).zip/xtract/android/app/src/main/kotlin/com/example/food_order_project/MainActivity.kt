package com.example.food_order_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
